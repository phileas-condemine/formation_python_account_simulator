# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['account', 'account.external', 'account.tests']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'formation-python-account-simulator',
    'version': '0.0.1',
    'description': 'Implementation of Banking Transactions.',
    'long_description': 'test push to github',
    'author': 'Philéas Condemine',
    'author_email': 'phileas.condemine@groupe-mma.fr',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
